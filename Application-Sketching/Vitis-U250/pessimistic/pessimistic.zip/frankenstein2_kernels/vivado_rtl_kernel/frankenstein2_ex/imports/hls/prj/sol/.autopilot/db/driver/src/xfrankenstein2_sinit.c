// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xfrankenstein2.h"

extern XFrankenstein2_Config XFrankenstein2_ConfigTable[];

XFrankenstein2_Config *XFrankenstein2_LookupConfig(u16 DeviceId) {
	XFrankenstein2_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFRANKENSTEIN2_NUM_INSTANCES; Index++) {
		if (XFrankenstein2_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFrankenstein2_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFrankenstein2_Initialize(XFrankenstein2 *InstancePtr, u16 DeviceId) {
	XFrankenstein2_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFrankenstein2_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFrankenstein2_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

